﻿
namespace Lintree.Common
{
    /// <summary>
    /// Bazowa klasa ViewModel, dziedziczy po ObservableObject.
    /// </summary>
    public abstract class ViewModelBase : ObservableObject
    {
    }
}
